**Work:** First-to-last [Codex and ChatGPT messages](documents.html), split at gaps over 15 minutes. Excludes automated prompts and unattended runs.

**X and Instagram:** First-to-last visits in each [session](sessions.html), split at gaps over five minutes.

**Friends:** [6:45–10:53 PM](source-document-085.html#google_timeline-0009), from Google Maps.

**Travel:** About 56 minutes [outward](source-document-085.html#google_timeline-0003) and 22 minutes [home](source-document-085.html#google_timeline-0010), including stops. Departure time is approximate.

**Spotify:** Sum of the [15 saved playback durations](source-document-087.html#spotify-0001), including partial plays.

Work and browsing periods can include breaks and overlap. They do not measure continuous attention.
